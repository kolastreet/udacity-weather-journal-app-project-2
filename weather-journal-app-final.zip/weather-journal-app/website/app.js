/* Global Variables */
const api='1b553aa202064003d8ed8325b759a203';
const apiUrl='http://api.openweathermap.org/data/2.5/weather?';

// api.openweathermap.org/data/2.5/weather?zip={zip code},{country code}&appid={API key}

// api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}

// api.openweathermap.org/data/2.5/weather?q={city name},{state code}&appid={API key}

// api.openweathermap.org/data/2.5/weather?q={city name},{state code},{country code}&appid={API key}




const dataFetch = async function () {
const zip = document.getElementById('zip').value;
const content = document.getElementById('feelings').value;
// convert zip code to number if it not number will be NaN
//https://www.w3schools.com/jsref/jsref_number.asp
const check= Number(zip);
// check for all letters and (,).. this will only return number if exist 
// https://www.w3schools.com/jsref/jsref_regexp_charset_not.asp
const check2=zip.match(/[^a-z,A-Z]/g);
//self check
console.log(check , check2);


	// data entered check
 if (content.length === 0 &&zip.length === 0) { 
     alert("Please Check City Field and How you feeling today Field "); 
    return
 }
 else if (zip.length === 0) {
    alert("Please Enter City Name or City ,Country code or City ,State code ,Country code or Zip Code >usa only< or Zip code ,Country code  !");
    return
 }
 
 else if (content.length === 0) {
    alert("How are you feeling today? is empty");
    return
 }

 
	
  if (Number.isInteger(check)) {
// this will work for usa only as default if there is no country code  
var url = `${apiUrl}zip=${zip}&units=metric&APPID=${api}`;
console.log('zip! '+url);
   
  } 
  // if check NaN then its text , if return from check2 is null then value was only text
else if ( !Number.isInteger(check) &&check2==null){
	// this will work on 3 situations .. (city only) x (city +state) x (city + state + country )
	var url = `${apiUrl}q=${zip}&units=metric&APPID=${api}`;
	console.log('city! '+url);
 
  }
else{
	// this will work on global but need to enter zip code + country code
  var url = `${apiUrl}zip=${zip}&units=metric&APPID=${api}`;
 
 console.log('zip and country '+url);

}
 
 
 
 /*  //this code will do same as last code but i prefer last one even this one have more cases which kinda delay performance alittle bit  :))
  if (zip.length === 0 || content.length === 0) {
    alert("Please Enter city name or City , country code or city ,state code , country code or zip code >usa only< or zip code , country code  !");
  return }
  
if ( !Number.isInteger(check) &&check2==null){
	// this will work on 3 situations .. (city only) x (city +state) x (city + state + country )
	var url = `${apiUrl}q=${zip}&units=metric&APPID=${api}`;
	console.log(url);
 
  }
else{
	// this will work on global but need to enter zip code + country code
  var url = `${apiUrl}zip=${zip}&units=metric&APPID=${api}`;
 
 console.log(url);


 }
 */
 
  let request = await fetch(url);
  console.log(request);
  
if (request.status===404){
	 alert("city or zip not found");
    return
}
  try {
    var data = await request.json();
     console.log(data);

    
  } catch (err) {
    console.log("Err:", err)
  }
 
 
  // Create a new date instance dynamically with JS
let d = new Date();
let newDate = (d.getMonth()+1)+ '.'+ d.getDate()+'.'+ d.getFullYear();
  console.log(newDate);
  
  //data = data.main["temp"];
  //newTemp= data.main["temp"];
  
  // add date to data to be single object
  // as in https://stackoverflow.com/questions/1168807/how-can-i-add-a-key-value-pair-to-a-javascript-object
  data["newDate"] = newDate;
  // also add feeling to data 
  data["feeling"] = content ;
  console.log(data);
  postData ('/all',data);
  
 // await getData ('/all');
  
 let finalData = await getData('/all');
console.log (finalData); 

	 // get value from object by key as  in https://stackoverflow.com/questions/17635866/get-values-from-an-object-in-javascript
 // let temp = data.main["temp"];
 // console.log(temp);
 
 
 
 fCountry= document.querySelector('#country').innerHTML = `${finalData.name} , ${finalData.sys["country"]}`;
 console.log(fCountry);
 
 fLocation= document.querySelector('#location').innerHTML = `Coordinates : Latitude ${finalData.coord["lat"]} , longitude ${finalData.coord["lon"]}`;
 
 fTemp=document.querySelector('#temp').innerHTML = `Temperature : ${finalData.main["temp"].toFixed(1)} °C | ${((finalData.main["temp"]*9/5)+32).toFixed(2)} °F`;
  console.log(fTemp);
  fFeel=document.querySelector('#feel').innerHTML = `Feel like : ${finalData.main["feels_like"].toFixed(1)} °C | ${((finalData.main["feels_like"]*9/5)+32).toFixed(2)} °F`;
 tMin=document.querySelector('#Tmin').innerHTML = `Temp Min : ${finalData.main["temp_min"].toFixed(1)} °C | ${((finalData.main["temp_min"]*9/5)+32).toFixed(2)} °F`;
 tMax=document.querySelector('#Tmax').innerHTML = `Temp Max : ${finalData.main["temp_max"].toFixed(1)} °C | ${((finalData.main["temp_max"]*9/5)+32).toFixed(2)} °F`;
 fPressure= document.querySelector('#pressure').innerHTML = `Pressure : ${finalData.main["pressure"]} hPa`;
 fHumidity = document.querySelector('#humidity').innerHTML = `Humidity : ${finalData.main["humidity"]}%`;
 fVisibility= document.querySelector('#visibility').innerHTML = `Visibility : ${(finalData["visibility"]/1000)}km`;
 
 fContent = document.querySelector('#content').innerHTML = `${finalData["feeling"]}`;
  fDate = document.querySelector('#date').innerHTML = `Date : ${finalData["newDate"]}`;
fwind = document.querySelector('#wind').innerHTML = `Speed : ${finalData.wind["speed"]}   ,Degree ${finalData.wind["deg"]}°`;
 fcloud = document.querySelector('#cloud').innerHTML = `Clouds : ${finalData.clouds["all"]}%`;
  //sun raise and sunset
  // https://stackoverflow.com/questions/847185/convert-a-unix-timestamp-to-time-in-javascript
 
function unixTime(x){
  let unix_timestamp = finalData.sys[x]
// Create a new JavaScript Date object based on the timestamp
// multiplied by 1000 so that the argument is in milliseconds, not seconds.
var date = new Date(unix_timestamp * 1000);
// Hours part from the timestamp
var hours = date.getHours();
// Minutes part from the timestamp
var minutes = "0" + date.getMinutes();
// Seconds part from the timestamp
var seconds = "0" + date.getSeconds();

// Will display time in 10:30:23 format
var formattedTime = hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);

return (formattedTime);
//console.log(formattedTime);
}
sunrises= unixTime ("sunrise");
sunsets= unixTime ("sunset");
console.log(sunrises,sunsets);

 sun = document.querySelector('#sun').innerHTML = `Sunrise : ${sunrises} ,  Sunset : ${sunsets}`;
 
}



const postData = async (url, data ) => {
  try {
    await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
	  
    })
	console.log (data);
	
	return (data); 
  } catch (error) {
    throw error
  }
} 

const getData= async function(url) {
  let response = await fetch(url)
  
  console.log (response);
  try {
    let data = await response.json();
    console.log(data);
    
   return data;
  } catch(err){
    console.log(err);
  }
  
}




document.getElementById('generate').addEventListener('click', dataFetch);

